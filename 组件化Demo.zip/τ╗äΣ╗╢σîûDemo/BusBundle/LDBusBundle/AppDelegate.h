//
//  AppDelegate.h
//  LDBusBundle
//
//  Created by 庞辉 on 11/15/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;


@end
