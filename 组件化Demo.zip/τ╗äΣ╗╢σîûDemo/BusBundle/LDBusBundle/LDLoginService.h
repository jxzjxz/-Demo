//
//  LDLoginService.h
//  LDBusBundle
//
//  Created by 庞辉 on 12/4/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//

@protocol LDLoginService <NSObject>
//测试实例方法
- (void)autologin;

@end
