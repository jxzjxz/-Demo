//
//  LDMPopWebViewController.h
//  LDBusBundle
//
//  Created by 庞辉 on 12/25/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LDMBusWebControllerProtocol.h"
#import "LDMWebContainer.h"

@interface LDMPopWebViewController : LDMWebContainer <LDMBusWebControllerProtocol>

@end
