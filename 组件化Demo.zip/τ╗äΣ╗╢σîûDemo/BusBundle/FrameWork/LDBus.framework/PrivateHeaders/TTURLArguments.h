//
//  Created by 庞辉 on 12/5/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//


// UINavigator (private)
#import "TTURLArgumentType.h"

TTURLArgumentType TTConvertArgumentType(char argType);
TTURLArgumentType TTURLArgumentTypeForProperty(Class cls, NSString* propertyName);

