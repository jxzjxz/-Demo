//
//  Created by 庞辉 on 12/5/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


/**
 * UITabBarController+TTCategory
 * 用于在Navigator导航时，如果viewController是UITabBarController时，进行导航判断和处理
 */
@interface UITabBarController (TTCategory)

@end
