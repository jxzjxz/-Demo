//
//  Created by 庞辉 on 12/5/14.
//  Copyright (c) 2014 庞辉. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


/**
 * UINavigationController+TTCategory
 * 用于在Navigator导航时，如果viewController是UINavigationController时，进行导航判断和处理
 */
@interface UINavigationController (TTCategory)

@end
